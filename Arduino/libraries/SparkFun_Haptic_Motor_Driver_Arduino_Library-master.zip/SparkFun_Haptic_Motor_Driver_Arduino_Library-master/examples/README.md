SparkFun Arduino Examples
==========================
3 example projects to get you started.

1. Heated Foot Massager 
2. Light Vibes
3. Audio to Vibe